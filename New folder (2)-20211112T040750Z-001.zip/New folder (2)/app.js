// chapter 21-25 STRING METHODS


// Question 2

// var phone = prompt("Enter your favorite mobile name")
// var phonelen = phone.length ;

// document.write(phone+"<br>");

// document.write("lenght:"+phonelen)


// Question 3

// var country = "pakistan";
// var len = country.length ("n")
// document.write(len)

// !problem

// Question 4


// var  text = 'Hello world'

// console.log(text.lastIndexOf("l"));


// Question 5

// var  text = 'Pakistani'

// console.log(text.charAt("3"));


// Question 7

// var city = "Hyderabad"
// console.log("CITY:"+city);

// var city = "Hyderabad";
// console.log(city.replace("Hyderabad", "Islamabad"))


// Question 8

// var message = "Ali and Sami are best friends. They play cricket and football together"

// console.log(message);

// for(var i = 0 ; i<message.length ; i++){

//       if( message.slice(i  ,  i + 3)   === "and" ){
//             message = message.slice(0 , i) + "&" + message.slice(i +3) 
//             console.log( "new message ==>>" , message);
// }  
// }


// Question 9

// var number = '1234.45'
// console.log(parseFloat(number , 10))


// Question 10


// var word = "peanuts"
// console.log(word.toUpperCase())


// Question 11


// var word = prompt("Type your favorite Hollywood Actress Name. Do not type Angelina jolie")
// var cap = word.charAt(0).toUpperCase() + word.slice(1);

// console.log(cap)


// Question 12

// var num = (123.123).toString();

// console.log(num)


// PROBLEM


// Question 14

    // var eat = ["cake" , "apple pie" , "cookie" , "chips" , "patties"];

    // var userInput = prompt("What do U liKe ¿?")
    
    // var file = "yep"
    
    // for(var i = 0 ; i < eat.length ; i++){
    
    //         if(userInput.toLowerCase() === "cake" ){
    //             alert("cake is AVAILABLE")
    //             file = "nop"
    //             break;
    //         }   
    //         else if(userInput === "cookies"){
    //         }   
    // }
    
    // if(file == "yep"){
    //     alert("not available")
    // }



// chapter 26-30 MATH METHODS


// Question 1

// var num = 20.25;
// var round = Math.round(num)
// var floor = Math.floor(num)
// var ceil = Math.ceil(num)
// console.log(round)
// console.log(floor)
// console.log(ceil)


// Question 2

// var num = -20.25;
// var round = Math.round(num)
// var floor = Math.floor(num)
// var ceil = Math.ceil(num)
// console.log(round)
// console.log(floor)
// console.log(ceil)


// Question 3

// var num = -5;
// var absolute = Math.abs(num)
// document.write(absolute)


// Question 4

// var iRandomNumber;
// var iDiceRoll;
// var i;

// for(i=1; i<=iDiceRoll; i++);
//     iRandomNumber = Math.ceil(Math.random()*6);
// document.write("random dice value:" + iRandomNumber)


// Question 5

// var headUser = prompt("Enter Your name HEAD USER" )
// var tailUser = prompt("Enter Your name TAIL USER" )

// var headScore = 0
// var tailScore = 0

// var toss = Math.floor( Math.random() * 2 + 1  )
// console.log(toss);

// if(toss == 1){
//         alert( headUser + " " +"HEAD USER Win")
  
// }else{
//         alert( tailUser + " " +"Tail USER Win")
// }


// Question 6 

// var random ;
// random = Math.ceil(Math.random()*100);
// document.write("random number:" + random);

